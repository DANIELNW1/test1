
import React from 'react';
import ReactDOM from 'react-dom/client';
import Koden_19042025 from './App';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Koden_19042025 />
  </React.StrictMode>
);
